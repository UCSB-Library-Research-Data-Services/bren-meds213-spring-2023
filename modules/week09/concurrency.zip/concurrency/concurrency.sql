PRAGMA journal_mode = WAL;
CREATE TABLE my_table (value INTEGER);
INSERT INTO my_table VALUES (0);
